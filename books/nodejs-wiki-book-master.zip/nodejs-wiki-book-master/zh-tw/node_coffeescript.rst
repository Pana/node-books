************
CoffeeScript
************

* Spine
* Hem
* Spine.app

Let's Have a Cup of CoffeeScript

* `es5-shim <https://github.com/kriskowal/es5-shim>`_ ECMAScript 5 compatibility shims for legacy JavaScript engines

ES.next

node-iform - A middleware for node-validator
https://github.com/guileen/node-iform


